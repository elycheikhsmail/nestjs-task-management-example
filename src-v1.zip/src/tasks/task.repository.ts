import { EntityRepository, Repository } from "typeorm";
import { Task } from "./task.entity";


export class TaskRepository extends Repository<Task> {

}