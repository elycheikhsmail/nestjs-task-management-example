import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuthCridentialsDto } from './dto/auth-cridentials.dto';
import { User } from './user.entity';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  async signUp(authCridentialDto: AuthCridentialsDto): Promise<void> {
    const { username, password } = authCridentialDto;
    const user = new User();
    user.username = username;
    user.password = password;
    await user.save();
  }
}
